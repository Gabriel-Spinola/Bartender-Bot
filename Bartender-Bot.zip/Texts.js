module.exports = {
    cardapio: `
Tá Aí Patrão!


**BEBIDAS GASOSAS** 🥃

**1-Refrigerantes**
- Cola-Cola
- Guarana Antartica
- Pepsi
- Fanta
- Sprite
- Guarana Jesus
- Itubaina
- Kuat

**2-Energeticas**
- RedBull
- TNT
- Monster
- Rockstar
- Fusion
- Dopamina
- Roxx Energy


**Bebidas Convensionais** 🥤


**1-Sucos Naturais**
- Suco de uva
- Suco de morango
- Suco de abacaxi
- Suco de goiaba
- Suco de maracuja
- Suco de melancia
- Suco de limão
- Suco de maçã
- Suco de manga
- Suco de laranja
- Suco de blue berry

**2-Bebidas Kids**
- Nescau
- Toddynho
- Batida de banana
- Milk Shake
- Ovomaltine
- Comidas 🍛


**ALIMENTAMENTOS NORMAIS**


**1-Tipicas Brasileiras**
- Feijoada
- Moqueca
- Acarajé
- Tacaca
- Baião de Dois
- Feijão Tropeiro
- Paçoca de carne seca
- Virado a paulista

**2-Porções**
- Porção de camarão
- Porção de batata
- Porção de peixe
- Porção de coxinha

**3-Variadas**
- Pastel
- Marmitex
- Bife
- Salgados
- Strogonoff
- Omelete
- Nhoque
- Lasanha`,
}